import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
import { writeFile } from "node:fs/promises";

const { chromium } = await import(process.env.PLAYWRIGHT_MODULE ? pathToFileURL(process.env.PLAYWRIGHT_MODULE).href : "playwright");
const frontend = process.env.FRONTEND_URL || "http://127.0.0.1:5173";
const backend = process.env.BACKEND_URL || "http://127.0.0.1:8080";
async function api(path, { token, method = "GET", body } = {}) {
  const response = await fetch(`${backend}/api${path}`, {
    method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json();
  assert.ok(response.ok, `${method} ${path}: ${JSON.stringify(data)}`);
  return data;
}
const stamp = Date.now();
const email = `carrito-prueba-${stamp}@example.test`;
const password = "PacientePrueba123!";
const patient = await api("/auth/register", { method: "POST", body: {
  nombre: "Prueba", apellido: "Carrito Redux", email, password, dni: String(stamp).slice(-9),
} });
const admin = await api("/auth/login", { method: "POST", body: { email: "admin@turnero.local", password: "AdminDemo123!" } });
const medicos = await api("/medicos");
const day = new Date(Date.now() + 17 * 86400000).toISOString().slice(0, 10);
const minute = Math.floor(stamp / 1000) % 1440;
const turno = await api("/turnos", { method: "POST", token: admin.token, body: {
  medicoId: medicos[0].id, fecha: { dia: day, hora: `${String(Math.floor(minute / 60)).padStart(2, "0")}:${String(minute % 60).padStart(2, "0")}` },
  precio: 12345.67, direccion: { calle: "Prueba Redux", altura: 123, ciudad: "Buenos Aires", codigoPostal: "1000" },
} });
const browser = await chromium.launch({ channel: "msedge", headless: true });
try {
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(`${frontend}/ingresar`);
  await page.getByLabel("Email", { exact: true }).fill(email);
  await page.getByLabel("Contraseña", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Ingresar", exact: true }).click();
  await page.waitForURL(`${frontend}/`);
  async function add() {
    await page.goto(`${frontend}/consultas/${turno.id}`);
    const response = page.waitForResponse((res) => res.url().endsWith("/api/carritos/add") && res.request().method() === "POST").then(async (res) => {
      assert.equal(res.status(), 200); return res.json();
    });
    await page.getByRole("button", { name: "Agregar al carrito", exact: true }).click();
    const cart = await response;
    assert.equal(cart.turnos[0].id, turno.id);
    await page.waitForURL(`${frontend}/carrito`);
    await page.getByRole("button", { name: "Quitar", exact: true }).waitFor();
    await page.locator('section[aria-busy="false"]').waitFor();
    return cart;
  }
  const cart = await add();
  const restored = page.waitForResponse((res) => res.url().endsWith("/api/carritos") && res.request().method() === "POST").then((res) => res.json());
  await page.reload();
  const recovered = await restored;
  assert.equal(recovered.id, cart.id);
  assert.equal(recovered.turnos[0].id, turno.id);
  assert.equal(recovered.total, 12345.67);
  await page.locator('section[aria-busy="false"]').waitFor();
  await page.getByRole("button", { name: "Quitar", exact: true }).waitFor();
  assert.ok((await page.locator(".resumen").innerText()).includes("12.345,67"));
  assert.deepEqual(await page.evaluate(() => Object.keys(localStorage)), ["turnero-med-sesion"]);
  assert.equal((await api(`/carritos/${cart.id}`, { token: patient.token })).turnos[0].id, turno.id);
  for (const name of ["Quitar", "Vaciar carrito", "Cancelar carrito"]) {
    await page.getByRole("button", { name, exact: true }).click();
    await page.getByText("Tu carrito está vacío.", { exact: true }).waitFor();
    await page.locator('section[aria-busy="false"]').waitFor();
    await add();
  }
  await page.getByRole("button", { name: "Confirmar turnos", exact: true }).click();
  await page.waitForURL(`${frontend}/mis-turnos`);
  const reservas = await api("/turnos/mis-turnos", { token: patient.token });
  assert.ok(reservas.some((t) => t.id === turno.id && t.estado === "TOMADO"));
  assert.deepEqual(errors, []);
  const result = { resultado: "OK", fecha: new Date().toISOString(), carritoId: cart.id, turnoId: turno.id, totalTrasRecarga: recovered.total,
    verificado: ["agregado desde Cart.jsx", "recarga real", "recuperación desde H2", "localStorage solo sesión", "quitar", "vaciar", "cancelar", "confirmar"], email };
  await writeFile("verificacion-carrito.json", JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result, null, 2));
} finally { await browser.close(); }
