import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { api } from "../../lib/api.js";

const initialState = {
  items: [], id: null, estado: null, venceEn: null, total: 0,
  isLoading: false, error: null, requestId: null, token: null,
};

const options = { condition: (_, { getState }) => !!getState().cart.token && !getState().cart.isLoading };
const request = (type, operation) => createAsyncThunk(type, async (arg, { getState, rejectWithValue }) => {
  try { return await operation(arg, getState().cart); }
  catch (error) { return rejectWithValue(error.message); }
}, options);

export const fetchCart = request("cart/fetch", (_, { token }) => api("/carritos", { token, method: "POST" }));
export const addToCart = request("cart/add", (producto, { token }) =>
  api("/carritos/add", { token, method: "POST", body: { id: producto.id } }));
export const removeFromCart = request("cart/remove", (id, cart) =>
  api(`/carritos/${cart.id}/turnos/${id}`, { token: cart.token, method: "DELETE" }));
export const clearCart = request("cart/clear", (_, cart) =>
  api(`/carritos/${cart.id}/turnos`, { token: cart.token, method: "DELETE" }));
export const cancelCart = request("cart/cancel", (_, cart) =>
  api(`/carritos/${cart.id}`, { token: cart.token, method: "DELETE" }));
export const confirmCart = request("cart/confirm", (_, cart) =>
  api(`/carritos/${cart.id}/confirmar`, { token: cart.token, method: "POST" }));

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    setCartSession(state, action) {
      if (state.token !== action.payload) return { ...initialState, token: action.payload };
    },
    resetCart: () => ({ ...initialState }),
  },
  extraReducers: (builder) => {
    for (const operation of [fetchCart, addToCart, removeFromCart, clearCart, cancelCart, confirmCart]) {
      builder.addCase(operation.pending, (state, action) => {
        state.isLoading = true; state.error = null; state.requestId = action.meta.requestId;
      });
      builder.addCase(operation.fulfilled, (state, action) => {
        // Una respuesta de una sesión cerrada no debe restaurar su carrito.
        if (state.requestId !== action.meta.requestId) return;
        const cart = action.payload;
        state.id = cart.id; state.estado = cart.estado; state.venceEn = cart.venceEn;
        state.items = cart.turnos; state.total = cart.total;
        state.isLoading = false; state.requestId = null;
      });
      builder.addCase(operation.rejected, (state, action) => {
        if (state.requestId !== action.meta.requestId) return;
        state.isLoading = false; state.requestId = null;
        state.error = action.payload || action.error.message;
      });
    }
  },
});

export const { setCartSession, resetCart } = cartSlice.actions;
export default cartSlice.reducer;
