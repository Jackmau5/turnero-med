import { test } from "node:test";
import assert from "node:assert/strict";
import { configureStore } from "@reduxjs/toolkit";
import cart, { setCartSession, addToCart, fetchCart } from "./cartSlice.js";

const makeStore = () => {
  const store = configureStore({ reducer: { cart } });
  store.dispatch(setCartSession("test-token"));
  return store;
};

test("add espera la base, maneja errores y recupera items en un store nuevo", async () => {
  const originalFetch = globalThis.fetch;
  const saved = { id: 7, estado: "ABIERTO", venceEn: "2030-01-01T12:00:00", turnos: [{ id: 2, precio: 100 }], total: 100 };
  try {
    let resolve;
    globalThis.fetch = (url, options) => {
      assert.equal(url, "/api/carritos/add");
      assert.deepEqual(JSON.parse(options.body), { id: 2 });
      return new Promise((done) => { resolve = done; });
    };
    const store = makeStore();
    const pending = store.dispatch(addToCart({ id: 2, precio: 1 }));
    assert.equal(store.getState().cart.isLoading, true);
    assert.deepEqual(store.getState().cart.items, []);
    resolve(new Response(JSON.stringify(saved)));
    await pending;
    assert.equal(store.getState().cart.isLoading, false);
    assert.equal(store.getState().cart.total, 100);
    assert.deepEqual(store.getState().cart.items, saved.turnos);
    globalThis.fetch = async () => new Response(JSON.stringify({ mensaje: "No disponible" }), { status: 409 });
    await store.dispatch(addToCart({ id: 3 }));
    assert.equal(store.getState().cart.error, "No disponible");
    assert.equal(store.getState().cart.isLoading, false);
    assert.deepEqual(store.getState().cart.items, saved.turnos);
    const reloaded = makeStore();
    assert.deepEqual(reloaded.getState().cart.items, []);
    globalThis.fetch = async () => new Response(JSON.stringify(saved));
    await reloaded.dispatch(fetchCart());
    assert.deepEqual(reloaded.getState().cart.items, saved.turnos);
  } finally { globalThis.fetch = originalFetch; }
});

test("las respuestas de una sesión anterior no restauran su carrito", async () => {
  const originalFetch = globalThis.fetch;
  try {
    let resolve;
    globalThis.fetch = () => new Promise((done) => { resolve = done; });
    const store = makeStore();
    const pending = store.dispatch(addToCart({ id: 2 }));
    store.dispatch(setCartSession(null));
    resolve(new Response(JSON.stringify({ id: 7, turnos: [{ id: 2 }], total: 100 })));
    await pending;
    assert.deepEqual(store.getState().cart.items, []);
    assert.equal(store.getState().cart.token, null);
  } finally { globalThis.fetch = originalFetch; }
});
