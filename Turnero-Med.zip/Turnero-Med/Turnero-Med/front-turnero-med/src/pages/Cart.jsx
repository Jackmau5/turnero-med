import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { especialidades, fechaLegible, pesos } from "../lib/api.js";
import { addToCart, fetchCart, removeFromCart, clearCart, cancelCart, confirmCart } from "../features/cart/cartSlice.js";

// El detalle reutiliza este botón: existe un solo flujo para agregar productos.
export function AgregarAlCarrito({ producto }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isLoading, error } = useSelector((state) => state.cart);
  async function agregar() {
    const result = await dispatch(addToCart(producto));
    if (addToCart.fulfilled.match(result)) navigate("/carrito");
  }
  return <>
    <button className="boton" disabled={isLoading} onClick={agregar}>{isLoading ? "Agregando…" : "Agregar al carrito"}</button>
    {error && <p className="error" role="alert">{error}</p>}
  </>;
}

export default function Cart() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { items, id, estado, venceEn, total, isLoading, error, token } = useSelector((state) => state.cart);
  const [aviso, setAviso] = useState("");
  useEffect(() => { dispatch(fetchCart()); }, [dispatch, token]);

  async function accion(operation, mensaje) {
    setAviso("");
    const result = await dispatch(operation);
    if (result.meta.requestStatus !== "fulfilled") return;
    if (confirmCart.fulfilled.match(result)) {
      navigate("/mis-turnos", { state: { aviso: `Reserva confirmada. Total: ${pesos.format(result.payload.total)}.` } });
    } else {
      setAviso(mensaje);
      if (cancelCart.fulfilled.match(result)) dispatch(fetchCart());
    }
  }

  return <section className="pagina" aria-busy={isLoading}>
    <p className="etiqueta">TU SELECCIÓN</p><h1>Carrito de turnos</h1>
    {isLoading && <p role="status">Actualizando carrito…</p>}
    {error && <div><p className="error" role="alert">{error}</p><button className="boton-secundario" disabled={isLoading} onClick={() => dispatch(fetchCart())}>Actualizar carrito</button></div>}
    {aviso && <p className="exito" role="status">{aviso}</p>}
    {id && estado === "ABIERTO" && <p className="aviso">Los horarios quedan reservados hasta {new Date(venceEn).toLocaleString("es-AR", { dateStyle: "short", timeStyle: "short" })}. Confirmá antes de ese momento.</p>}
    {!isLoading && items.length === 0 && <div className="panel"><p>Tu carrito está vacío.</p><Link to="/">Buscar horarios</Link></div>}
    {items.length > 0 && <>
      <div className="lista-paneles">{items.map((turno) => <article className="panel fila" key={turno.id}>
        <div><span className="especialidad">{especialidades[turno.especialidad]}</span><h2>{turno.medicoNombre}</h2>
          <p>{fechaLegible(turno)} · {turno.direccion.calle} {turno.direccion.altura}</p>
          <strong>{pesos.format(turno.precio)}</strong></div>
        <button className="boton-secundario" disabled={isLoading || estado !== "ABIERTO"} onClick={() => accion(removeFromCart(turno.id), "Turno quitado del carrito.")}>Quitar</button>
      </article>)}</div>
      <div className="panel resumen"><span>Total de la reserva</span><strong>{pesos.format(total)}</strong></div>
      <div className="acciones">
        <button className="boton" disabled={isLoading || estado !== "ABIERTO"} onClick={() => accion(confirmCart())}>Confirmar turnos</button>
        <button className="boton-secundario" disabled={isLoading || estado !== "ABIERTO"} onClick={() => accion(clearCart(), "Carrito vaciado.")}>Vaciar carrito</button>
        <button className="boton-secundario" disabled={isLoading || estado !== "ABIERTO"} onClick={() => accion(cancelCart(), "Carrito cancelado.")}>Cancelar carrito</button>
      </div>
    </>}
  </section>;
}
