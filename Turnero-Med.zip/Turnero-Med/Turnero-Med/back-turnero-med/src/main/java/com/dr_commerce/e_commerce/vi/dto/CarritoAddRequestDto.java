package com.dr_commerce.e_commerce.vi.dto;

// El producto es un turno. El precio se consulta siempre en la base.
public record CarritoAddRequestDto(Long id) {}
