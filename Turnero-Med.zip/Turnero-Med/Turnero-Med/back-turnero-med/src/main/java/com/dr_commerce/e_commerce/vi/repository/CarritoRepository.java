package com.dr_commerce.e_commerce.vi.repository;

import com.dr_commerce.e_commerce.vi.model.Carrito;
import com.dr_commerce.e_commerce.vi.model.EstadoCarrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    @org.springframework.data.jpa.repository.Query("select c from Carrito c where c.paciente.id = :pacienteId order by c.id desc")
    java.util.List<Carrito> getAll(@org.springframework.data.repository.query.Param("pacienteId") Long pacienteId);

    default Optional<Carrito> getByID(Long id) { return findById(id); }
    default Carrito add(Carrito carrito) { return save(carrito); }

    // Baja lógica; el Service libera previamente los turnos para conservar el historial.
    @Override
    @org.springframework.transaction.annotation.Transactional
    default void delete(Carrito carrito) {
        carrito.setEstado(EstadoCarrito.CANCELADO);
        save(carrito);
    }


    java.util.List<Carrito> findByEstadoAndVenceEnBefore(EstadoCarrito estado, java.time.LocalDateTime ahora);

    Optional<Carrito> findByPacienteIdAndEstado(Long pacienteId, EstadoCarrito estado);
    @org.springframework.data.jpa.repository.Query("select c.paciente.id from Carrito c where c.id = :id")
    java.util.Optional<Long> buscarPacienteId(@org.springframework.data.repository.query.Param("id") Long id);
    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @org.springframework.data.jpa.repository.Query("select e from Carrito e where e.id = :id")
    java.util.Optional<Carrito> buscarConBloqueo(@org.springframework.data.repository.query.Param("id") Long id);
}
