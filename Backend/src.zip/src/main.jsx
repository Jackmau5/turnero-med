import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import ProductList from './components/ProductList.jsx';
import './index.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ProductList />
  </StrictMode>,
);
