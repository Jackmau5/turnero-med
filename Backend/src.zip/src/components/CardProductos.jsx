import React from 'react';
import './CardProductos.css';

const CardProductos = ({ product }) => {
  return (
    <article className="card-producto">
      <h2>{product.nombre}</h2>
      <p>{product.descripcion}</p>
      <p className="producto-precio">Precio: ${product.precio} ARS</p>
      <button type="button" className="btn-solicitar">
        Solicitar turno
      </button>
    </article>
  );
};

export default CardProductos;
