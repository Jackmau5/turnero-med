import React from 'react';
import products from '../data/products.json';
import CardProductos from './CardProductos';
import './ProductList.css';

const ProductList = () => {
  return (
    <main className="product-list-container">
      <h1 className="product-list-title">Prestaciones del Turnero</h1>
      <div className="products-grid">
        {products.map((product) => (
          <CardProductos key={product.id} product={product} />
        ))}
      </div>
    </main>
  );
};

export default ProductList;
